===============================
gluon
===============================

A Model-Driven, Extensible Framework for L3 Networking Services

Please fill here a long description which must be at least 3 lines wrapped on
80 cols, so that distribution package maintainers can use it in their packages.
Note that this is a hard requirement.

* Free software: Apache license
* Documentation: http://docs.openstack.org/developer/gluon
* Source: http://git.openstack.org/cgit/openstack/gluon
* Bugs: http://bugs.launchpad.net/python-gluon

Features
--------

* TODO
