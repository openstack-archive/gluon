============
Installation
============

At the command line::

    $ pip install gluon

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv gluon
    $ pip install gluon
